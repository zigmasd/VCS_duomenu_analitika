######################################################################
###
###			Student
###			name: Zigmas
###			surname: Dičpinigaitis
###
#######################################################################
### 	A total of 19 points can be collected. 19 t = 10 points. 	###
#######################################################################

/* 
*	TASK 01: 
*	(1 point)
*	Submit only those payments whose value (amount) is greater than 2. 
*   Use the payment table.
*/
	
	select * from sakila.payment where amount > 2;
    
/* 
*	TASK 02: 
*	(1 point)
*	Submit movies with a rating of PG
*	and a replacement_cost of less than 10. 
*    Use the table in film.
*/
	
    select * from sakila.film where rating = 'PG' and replacement_cost < 10;
    
/* 
*	TASK 03: 
*	(1 point)
*	Calculate the average rental rate (rental_rate) for each
*	for rated movies, enter your answer with only 2 decimal places. 
*   Do not round! Simply "cut off" the answer at two decimal places.
*	Use the table in film.
*/
	
    select rating, TRUNCATE(AVG(rental_rate), 2) from sakila.film group by 1;
    
/* 
*	TASK 04: 
*	(1 point)
*	Print the names of all customers (first_name), and next to the first_name column,
*	count the length of each name (how many letters are in the name).
*	Use the customer table
*/
	
    select first_name, length(first_name) from sakila.customer;
    
/* 
*	TASK 05: 
*	(1 point)
*	Explore the raised letter is "e" in the description of each movie.
*	Use the table in film.
*/    
    
    select description, locate('e', description) from sakila.film;
    
/* 
*	TASK 06: 
*	(2 points)
*	Add up the total length of movies for each rating.
*	Print only ratings with a total length of movies
*	greater than 22000.
*	Use the table in film.
*/   
	
    select rating, sum(length) from sakila.film group by rating having sum(length) > 22000;
    
/* 
*	TASK 07: 
*	(2 points)
*	Print descriptions of all movies, print next to them
*	the number of elements that make up the descriptions. In the third column, print
*	the number of items in the descriptions, changing all letters "a" to "OO" in them.
*	This means you have to change all letters "a" to "OO" in the description and then
*	count the number of elements in the new object.
*	Use the film_text table.
*/ 
	
    select description, length(description), length(replace(description, 'a', 'OO')) from sakila.film_text;
    
/* 
*	TASK 08: 
*	(3 points)
*	Write an SQL query that would sort movies based on their ratings (rating)
*	into the following categories::
*		If the rating is "PG" or "G" then "PG_G"
*		If the rating is "NC-17" or "PG-13" then "NC-17-PG-13"
*		Classify all other ratings as "Irrelevant"
*	Display the categories in the "Rating_group" column
*	Use the table in film.
*/ 
	
    select 
        rating, 
        CASE 
			WHEN rating = 'PG' or rating = 'G' THEN 'PG_G'
            WHEN rating = 'NC-17' or rating = 'PG-13' THEN 'NC-17-PG-13'
            ELSE 'Irrelevant'
		END as Rating_group
    from sakila.film group by rating;
    
/* 
*	TASK 09: 
*	(3 points)
*	Total rental duration (rental_duration) for each
*	movie category (name). 
*	Print only categories with rental_duration sum
*	greater than 300. 
*	Complete the task by joining the tables. 
*	Use the tables film, film_category, category.
*/ 
	
    select C.name, sum(A.rental_duration) from sakila.film A
		JOIN sakila.film_category B ON A.film_id = B.film_id
        JOIN sakila.category C ON B.category_id = C.category_id
    group by 1
    having sum(A.rental_duration) > 300;
    
/* 
*	TASK 10: 
*	(4 points with subquery, without subguery 2 points)
*	Provide the first_name (first_name) and last_name (last_name) of the customers who
*	rented the movie "AGENT TRUMAN". Perform the task using a subquery.
*	Task performed correctly without subquery is rated 2 points. 
*	Use the tables customer, rental, inventory, film.
*/ 
	
	select A.first_name, A.last_name from sakila.customer A
		WHERE A.customer_id in 
			
            (
            select B.customer_id 
            from sakila.rental B
			WHERE B.inventory_id in
					
                    (
                    select C.inventory_id 
                    from sakila.inventory C
                    WHERE C.film_id in
                    
						(
                        select D.film_id 
                        from sakila.film D
                        WHERE D.title = 'AGENT TRUMAN'
                        )
                    
                    )
            
            );


    
    
    
    
    
    