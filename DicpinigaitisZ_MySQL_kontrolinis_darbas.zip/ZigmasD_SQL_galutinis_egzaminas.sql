######################################################################
###
###			Studentas
###			vardas: Zigmas
###			pavarde: Dičpinigaitis
###
#######################################################################
### 		Viso galima surinkti 19 taškų. 19 t = 10 balų. 			###
#######################################################################

/* 
*	UŽDUOTIS 01: 
*	(1 taškas)
*	Pateikite tik tuos mokėjimus, kurių vertė (amount) yra didesnė nei 2. 
*   Naudokite lentelę payment.
*/
	
	select * from sakila.payment where amount > 2;
    
/* 
*	UŽDUOTIS 02: 
*	(1 taškas)
*	Pateikite filmus, kurių reitingas (rating) yra „PG“,
*	o pakeitimo kaina (replacement_cost) yra mažesnė nei 10. 
*    Naudokite lentelę film.
*/
	
    select * from sakila.film where rating = 'PG' and replacement_cost < 10;
    
/* 
*	UŽDUOTIS 03: 
*	(1 taškas)
*	Suskaičiuokite vidutinę nuomos kainą (rental_rate) kiekvieno
*	reitingo filmams, atsakymą pateikite tik su 2 skaičiais po kablelio. 
*   Ne apvalinti! Tiesiog „nupjauti“ atsakymą ties dviem skaičiais po kablelio. 
*	Naudokite lentelę film.
*/
	
    select rating, TRUNCATE(AVG(rental_rate), 2) from sakila.film group by 1;
    
/* 
*	UŽDUOTIS 04: 
*	(1 taškas)
*	Išspausdinkite visų klientų vardus (first_name), o šalia vardų stulpelio
*	suskaičiuokite kiekvieno vardo ilgį (kiek varde yra raidžių). 
*	Naudokite lentelę customer
*/
	
    select first_name, length(first_name) from sakila.customer;
    
/* 
*	UŽDUOTIS 05: 
*	(1 taškas)
*	Ištirkite kelinta raidė yra „e“ kiekvieno filmo aprašyme (description).
*	Naudokite lentelę film.
*/    
    
    select description, locate('e', description) from sakila.film;
    
/* 
*	UŽDUOTIS 06: 
*	(2 taškai)
*	Susumuokite kiekvieno reitingo (rating) bendrą filmų trukmę (length).
*	Išspausdinkite tik tuos reitingus, kurių bendra filmų trukmė yra
*	ilgesnė nei 22000.
*	Naudokite lentelę film.
*/   
	
    select rating, sum(length) from sakila.film group by rating having sum(length) > 22000;
    
/* 
*	UŽDUOTIS 07: 
*	(2 taškai)
*	Išspausdinkite visų filmų aprašymus (description), šalia išspausdinkite
*	aprašymus sudarančių elementų skaičių. Trečiame stulpelyje išspausdinkite
*	aprašymų elementų skaičių, juose visas raides „a“ pakeisdami į „OO“.
*	Tai reiškia turite aprašyme visas raides „a“ pakeisti į „OO“ ir tada
*	suskaičiuoti naujo objekto elementų skaičių. 
*	Naudokite lentelę film_text.
*/ 
	
    select description, length(description), length(replace(description, 'a', 'OO')) from sakila.film_text;
    
/* 
*	UŽDUOTIS 08: 
*	(3 taškai)
*	Parašykite SQL užklausą, kuri suskirstytų filmus pagal jų reitingus (rating)
*	į tokias kategorijas:
*		Jei reitingas yra „PG“ arba „G“ tada „PG_G“
*		Jei reitingas yra „NC-17“ arba „PG-13“ tada „NC-17-PG-13“
*		Visus kitus reitingus priskirkite kategorijai „Nesvarbu“
*	Kategorijas atvaizduokite stulpelyje „Reitingo_grupe“
*	Naudokite lentelę film.
*/ 
	
    select 
        rating, 
        CASE 
			WHEN rating = 'PG' or rating = 'G' THEN 'PG_G'
            WHEN rating = 'NC-17' or rating = 'PG-13' THEN 'NC-17-PG-13'
            ELSE 'Nesvarbu'
		END as Reitingo_grupe
    from sakila.film group by rating;
    
/* 
*	UŽDUOTIS 09: 
*	(3 taškai)
*	Susumuokite nuomavimosi trukmę (rental_duration), kiekvienanai filmo
*	kategorijai (name). 
*	Išspausdinkite tik tas kategorijos, kurių rental_duration suma yra 
*	didesnė nei 300. 
*	Užduotį atlikite apjungiant lenteles. 
*	Naudokite lenteles film, film_category, category.
*/ 
	
    select C.name, sum(A.rental_duration) from sakila.film A
		JOIN sakila.film_category B ON A.film_id = B.film_id
        JOIN sakila.category C ON B.category_id = C.category_id
    group by 1
    having sum(A.rental_duration) > 300;
    
/* 
*	UŽDUOTIS 10: 
*	(4 taškai su subquery, be subguery 2 taškai)
*	Pateikite klientų vardus (first_name) ir pavardes (last_name), kurie 
*	išsinuomavo filmą „AGENT TRUMAN“. Užduotį atlikite naudodami subquery.
*	Užduotis atlikta teisingai be subquery vertinama 2t. 
*	Naudokite lenteles customer, rental, inventory, film.
*/ 
	
	select A.first_name, A.last_name from sakila.customer A
		WHERE A.customer_id in 
			
            (
            select B.customer_id 
            from sakila.rental B
			WHERE B.inventory_id in
					
                    (
                    select C.inventory_id 
                    from sakila.inventory C
                    WHERE C.film_id in
                    
						(
                        select D.film_id 
                        from sakila.film D
                        WHERE D.title = 'AGENT TRUMAN'
                        )
                    
                    )
            
            );


    
    
    
    
    
    